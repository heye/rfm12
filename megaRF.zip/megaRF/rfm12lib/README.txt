Visit http://www.das-labor.org/wiki/RFM12_library/en (english)
or http://www.das-labor.org/wiki/RFM12_library (german)